package org.example;

import java.util.List;
import java.util.stream.IntStream;

class OddNumberFilter {

    public static void main(String[] args) {

        // Provide a list of numbers from 1 to 10
        List<Integer> numbers = IntStream.rangeClosed(1, 10)
                .boxed()
                .toList();

        // Filter out the even numbers and print only the odd numbers
        List<Integer> oddNumbers = numbers.stream()
                .filter(num -> num % 2 != 0)
                .toList();

        // Output the odd numbers to the console
        System.out.println("Odd numbers: " + oddNumbers);
    }
}
package com.example.demo.service;

import com.example.demo.entity.Customer;
import com.example.demo.repository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

@Service
public class CustomerService {

    @Autowired
    private CustomerRepository customerRepository;

    public Page<Customer> getCustomers(String name, Pageable pageable) {
        return customerRepository.findByNameContaining(name, pageable);
    }

    public Customer addCustomer(Customer customer) {
        return customerRepository.save(customer);
    }
}
